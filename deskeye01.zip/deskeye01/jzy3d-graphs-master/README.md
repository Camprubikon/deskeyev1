jzy3d-graphs
============

A set of tools to compute and draw 3d graphs layouts based on Gephi Toolkit.

<img src="doc/graph7.png">

Example programs in src/main/java

org.jzy3d.graphs.trials.ImportAndDrawTrial

More information at http://www.jzy3d.org/plugins-graphs.php
