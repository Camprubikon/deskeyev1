package org.jzy3d.graphs.gephi.layout;

import org.gephi.layout.spi.Layout;

public interface IOnStepDoneListener {
    public void stepDone(Layout layout);
}
