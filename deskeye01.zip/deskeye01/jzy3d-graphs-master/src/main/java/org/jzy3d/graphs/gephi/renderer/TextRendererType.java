package org.jzy3d.graphs.gephi.renderer;

public enum TextRendererType {
    BITMAP,
    BILLBOARD
}
